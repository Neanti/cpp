//
// Created by neati on 11/02/19.
//

#ifndef CPP_FILE_H
#define CPP_FILE_H


#include "Liste.h"

class File {
private:
    Liste l;
public:
    void del_back();
    void add_front(int d);


};


#endif //CPP_FILE_H
