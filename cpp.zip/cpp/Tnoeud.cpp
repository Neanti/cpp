//
// Created by neati on 11/02/19.
//

#include "Tnoeud.h"
template class Tnoeud<int>;
template class Tnoeud<char*>;
