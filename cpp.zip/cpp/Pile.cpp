//
// Created by neati on 11/02/19.
//

#include "Pile.h"

void Pile::add_back(int d) {
    l.add_back(d);
}

void Pile::del_back() {
    l.del_back();
}
