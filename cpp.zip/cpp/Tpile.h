//
// Created by neati on 11/02/19.
//

#ifndef CPP_TPILE_H
#define CPP_TPILE_H

#include "Tlist.h"

template <class T>
class Tpile {
private:

public:


};


#endif //CPP_TPILE_H
