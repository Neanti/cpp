//
// Created by neati on 11/02/19.
//

#ifndef CPP_PILE_H
#define CPP_PILE_H


#include "Liste.h"

class Pile {
    private:
        Liste l;
    public:
    void add_back(int d);
    void del_back();


};


#endif //CPP_PILE_H
