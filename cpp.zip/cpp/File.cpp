//
// Created by neati on 11/02/19.
//

#include "File.h"

void File::del_back() {
    l.del_back();
}

void File::add_front(int d) {
    l.add_front(d);
}
